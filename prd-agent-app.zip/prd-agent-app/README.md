# PRD Agent ⚡

An AI-powered Product Requirements Document generator with 3 modes:
- **Guided Interview** — step-by-step questions to build your PRD
- **Notes → PRD** — paste rough notes, get a structured PRD
- **Template + AI** — fill sections with AI assistance

---

## 🚀 Deploy to Vercel (Easiest — 5 minutes)

### Step 1: Push to GitHub
1. Go to [github.com/new](https://github.com/new) and create a new repository (e.g., `prd-agent`)
2. Upload all these project files to the repo (drag & drop works!)

### Step 2: Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click **"Add New Project"**
3. Select your `prd-agent` repository
4. Before clicking Deploy, expand **"Environment Variables"** and add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your API key (starts with `sk-ant-...`)
5. Click **Deploy**

### Step 3: Done! 🎉
Vercel gives you a URL like `prd-agent.vercel.app` — bookmark it and use daily.

---

## 💻 Run Locally (Alternative)

```bash
# 1. Install dependencies
npm install

# 2. Add your API key
cp .env.local.example .env.local
# Edit .env.local and paste your real key

# 3. Run
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🔒 Security Note

Your API key is kept **server-side only** via the `/api/generate` route. It never reaches the browser. The Vercel environment variable is encrypted at rest.

---

## 📁 Project Structure

```
prd-agent-app/
├── app/
│   ├── api/generate/route.js   ← Secure API proxy
│   ├── layout.js               ← Root layout + fonts
│   └── page.js                 ← Main PRD Agent UI
├── .env.local.example          ← API key template
├── .gitignore
├── next.config.js
├── package.json
└── README.md
```
