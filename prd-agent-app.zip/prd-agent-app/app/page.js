"use client";
import { useState, useRef, useEffect } from "react";

const MODES = [
  { id: "interview", label: "Guided Interview", icon: "\u{1F4AC}", desc: "I'll ask you questions step by step" },
  { id: "notes", label: "Notes \u2192 PRD", icon: "\u{1F4DD}", desc: "Paste rough notes and I'll structure them" },
  { id: "template", label: "Template + AI", icon: "\u{1F4CB}", desc: "Fill in sections with AI help" },
];

const QUESTIONS = [
  { key: "product_name", q: "What\u2019s the name of the product or feature?", placeholder: "e.g., In-App Loyalty Streaks" },
  { key: "problem", q: "What problem are you solving? Who experiences it?", placeholder: "Describe the pain point and who feels it...", multi: true },
  { key: "hypothesis", q: "What\u2019s your hypothesis? Why will your solution work?", placeholder: "We believe that [doing X] for [user Y] will [achieve Z] because...", multi: true },
  { key: "users", q: "Who are your target users?", placeholder: "e.g., Existing app users aged 18-35 in urban areas who order coffee 2x/week", multi: true },
  { key: "user_stories", q: "What should users be able to do? List 2\u20134 key user stories.", placeholder: "As a [user], I want to [action] so that [benefit]...", multi: true },
  { key: "requirements", q: "Any specific functional requirements or must-haves?", placeholder: "e.g., Must integrate with existing rewards system, needs push notification support...", multi: true },
  { key: "metrics", q: "How will you measure success? What KPIs matter?", placeholder: "e.g., +20% D30 retention, +15% repeat order frequency, >30% open rate", multi: true },
  { key: "out_of_scope", q: "Anything explicitly out of scope?", placeholder: "e.g., International localization, advanced ML models in V1...", multi: true },
];

const SECTIONS = [
  { key: "problem_statement", title: "Problem Statement & Hypothesis", placeholder: "Describe the problem, who it affects, and your hypothesis...", ai: "Help me refine this" },
  { key: "user_stories", title: "User Stories & Requirements", placeholder: "List user stories and requirements...", ai: "Generate user stories" },
  { key: "success_metrics", title: "Success Metrics & KPIs", placeholder: "Define metrics, targets, and measurement approach...", ai: "Suggest metrics" },
];

const SYS = `You are a senior Product Manager AI assistant specialized in writing world-class PRDs. Output should include: 1. Overview 2. Problem Statement & Hypothesis 3. Target Users 4. User Stories 5. Functional Requirements 6. Non-Functional Requirements 7. Success Metrics & KPIs 8. Out of Scope 9. Dependencies & Risks. Use clean markdown. Be specific, quantitative, and actionable.`;

async function callAI(messages) {
  try {
    const r = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages, system: SYS }),
    });
    const d = await r.json();
    if (d.error) return "Error: " + d.error;
    return d.content?.map(b => b.type === "text" ? b.text : "").filter(Boolean).join("\n") || "Could not generate. Try again.";
  } catch { return "Error connecting. Please try again."; }
}

function renderMd(t) {
  if (!t) return "";
  return t
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/^### (.+)$/gm, '<h3 class="mh3">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 class="mh2">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 class="mh1">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/^- (.+)$/gm, '<li class="mli">$1</li>')
    .replace(/^(\d+)\. (.+)$/gm, '<li class="moli">$2</li>')
    .replace(/\n{2,}/g, "<br/><br/>").replace(/\n/g, "<br/>");
}

export default function Page() {
  const [mode, setMode] = useState(null);
  const [step, setStep] = useState(0);
  const [ans, setAns] = useState({});
  const [input, setInput] = useState("");
  const [notes, setNotes] = useState("");
  const [tpl, setTpl] = useState({});
  const [prd, setPrd] = useState("");
  const [loading, setLoading] = useState(false);
  const [secLoad, setSecLoad] = useState(null);
  const [copied, setCopied] = useState(false);
  const iRef = useRef(null);
  const oRef = useRef(null);

  useEffect(() => { iRef.current?.focus(); }, [step, mode]);
  useEffect(() => { if (prd && oRef.current) oRef.current.scrollIntoView({ behavior: "smooth" }); }, [prd]);

  const next = () => {
    if (!input.trim()) return;
    setAns(a => ({ ...a, [QUESTIONS[step].key]: input.trim() }));
    setInput("");
    if (step < QUESTIONS.length - 1) setStep(s => s + 1);
  };
  const back = () => { if (step > 0) { setInput(ans[QUESTIONS[step - 1].key] || ""); setStep(s => s - 1); } };

  const genInterview = async () => {
    const fa = { ...ans }; if (input.trim()) fa[QUESTIONS[step].key] = input.trim(); setAns(fa);
    setLoading(true);
    const s = Object.entries(fa).map(([k, v]) => `${k}: ${v}`).join("\n\n");
    setPrd(await callAI([{ role: "user", content: `Generate a complete PRD from these interview answers:\n\n${s}` }]));
    setLoading(false);
  };

  const genNotes = async () => {
    if (!notes.trim()) return; setLoading(true);
    setPrd(await callAI([{ role: "user", content: `Convert these rough notes into a complete PRD. Infer structure, mark assumptions as [ASSUMPTION]:\n\n${notes}` }]));
    setLoading(false);
  };

  const aiSec = async (sec) => {
    setSecLoad(sec.key);
    const ctx = Object.entries(tpl).filter(([k, v]) => k !== sec.key && v?.trim()).map(([k, v]) => `${k}: ${v}`).join("\n\n");
    const cur = tpl[sec.key] || "";
    const msg = cur
      ? `Improve the "${sec.title}" section.\n${ctx ? `Context:\n${ctx}\n\n` : ""}Current draft:\n${cur}\n\nMake it specific and actionable. Only section content in markdown.`
      : `Generate a strong "${sec.title}" section.\n${ctx ? `Context:\n${ctx}\n\n` : ""}Only section content in markdown.`;
    const r = await callAI([{ role: "user", content: msg }]);
    setTpl(d => ({ ...d, [sec.key]: r })); setSecLoad(null);
  };

  const genTpl = async () => {
    const f = Object.entries(tpl).filter(([, v]) => v?.trim()).map(([k, v]) => `${k}:\n${v}`).join("\n\n---\n\n");
    if (!f) return; setLoading(true);
    setPrd(await callAI([{ role: "user", content: `Combine these sections into a polished, complete PRD. Fill missing sections:\n\n${f}` }]));
    setLoading(false);
  };

  const copy = () => { navigator.clipboard.writeText(prd); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const reset = () => { setMode(null); setStep(0); setAns({}); setInput(""); setNotes(""); setTpl({}); setPrd(""); setLoading(false); setSecLoad(null); };

  const isLast = step === QUESTIONS.length - 1;
  const q = QUESTIONS[step];

  return (
    <div className="root">
      <style>{`
        .root {
          --bg:#0C0E14;--s1:#151822;--s2:#1E2230;--bd:#2A2F42;--tx:#D8DBE8;--tx2:#727898;
          --ac:#7C6BF0;--ac2:#A89CF8;--acg:rgba(124,107,240,0.1);--hd:#ECEEF6;--ok:#34D399;
          background:var(--bg);color:var(--tx);min-height:100vh;font-family:'DM Sans',sans-serif;
        }
        .root *{box-sizing:border-box}
        .w{max-width:660px;margin:0 auto;padding:44px 24px}
        .ww{max-width:740px;margin:0 auto;padding:40px 24px}
        .c{background:var(--s1);border:1px solid var(--bd);border-radius:14px;padding:24px;transition:border-color .15s}
        .c:hover{border-color:color-mix(in srgb,var(--ac) 30%,var(--bd))}
        .badge{font-size:12px;font-weight:600;color:var(--ac2);letter-spacing:2px;text-transform:uppercase}
        .tt{font-size:30px;font-weight:700;color:var(--hd);margin:10px 0 8px;line-height:1.2}
        .sub{color:var(--tx2);font-size:14px;line-height:1.5}
        .bp{border:none;border-radius:10px;padding:11px 24px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;background:var(--ac);color:#fff}
        .bp:hover{filter:brightness(1.1)}.bp:disabled{opacity:.35;cursor:default}
        .bok{background:var(--ok);color:#0C0E14}.bok:hover{filter:brightness(1.1)}.bok:disabled{opacity:.35;cursor:default}
        .bs{background:transparent;color:var(--ac2);border:1px solid var(--bd);border-radius:10px;padding:9px 18px;font-size:13px;font-weight:500;cursor:pointer;font-family:inherit;transition:all .15s}
        .bs:hover{border-color:var(--ac);background:var(--acg)}
        .ta{width:100%;background:var(--s2);color:var(--tx);border:1px solid var(--bd);border-radius:10px;padding:14px 16px;font-size:14px;font-family:inherit;resize:vertical;outline:none;line-height:1.6}
        .ta:focus{border-color:var(--ac);box-shadow:0 0 0 2px var(--acg)}
        .inp{width:100%;background:var(--s2);color:var(--tx);border:1px solid var(--bd);border-radius:10px;padding:14px 16px;font-size:15px;font-family:inherit;outline:none}
        .inp:focus{border-color:var(--ac);box-shadow:0 0 0 2px var(--acg)}
        .dot{width:9px;height:9px;border-radius:50%;transition:all .3s}
        .don{background:var(--ac);box-shadow:0 0 8px var(--ac)}.dd{background:var(--ac2)}.dof{background:var(--bd)}
        .mb{cursor:pointer;display:flex;align-items:center;gap:16px;text-align:left}
        .mb:hover{border-color:var(--ac)!important;box-shadow:0 0 24px var(--acg)}
        .ib{font-size:26px;width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:var(--s2);border-radius:12px;flex-shrink:0}
        .rb{display:flex;gap:10px;align-items:center}.rbb{display:flex;justify-content:space-between;align-items:center}
        .mh1{font-size:20px;font-weight:700;margin:24px 0 10px;color:var(--hd)}
        .mh2{font-size:17px;font-weight:700;margin:20px 0 8px;color:var(--hd)}
        .mh3{font-size:15px;font-weight:600;margin:16px 0 6px;color:var(--hd)}
        .mli{margin:3px 0 3px 20px;list-style:disc}.moli{margin:3px 0 3px 20px;list-style:decimal}
        @keyframes spin{to{transform:rotate(360deg)}}
        .sp{display:inline-block;width:14px;height:14px;border:2px solid var(--bd);border-top-color:var(--ac2);border-radius:50%;animation:spin .6s linear infinite;vertical-align:middle;margin-right:6px}
        @keyframes fi{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}.fi{animation:fi .35s ease}
        .pa{margin-top:20px}.pi{margin-bottom:8px;padding:10px 14px;background:var(--s2);border-radius:8px;font-size:13px}
        .pq{color:var(--tx2);margin-bottom:2px;font-size:12px}
      `}</style>

      {/* MODE SELECT */}
      {!mode && !prd && !loading && (
        <div className="w fi">
          <div style={{textAlign:"center",marginBottom:36}}>
            <div className="badge">PRD Agent</div>
            <h1 className="tt">Build your PRD with AI</h1>
            <p className="sub">Choose how you'd like to get started</p>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            {MODES.map(m=>(
              <button key={m.id} className="c mb" onClick={()=>setMode(m.id)}>
                <div className="ib">{m.icon}</div>
                <div>
                  <div style={{fontWeight:600,fontSize:15,color:"var(--hd)",marginBottom:2}}>{m.label}</div>
                  <div style={{fontSize:13,color:"var(--tx2)"}}>{m.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* PRD OUTPUT */}
      {prd && (
        <div className="ww fi" ref={oRef}>
          <div className="rbb" style={{marginBottom:20}}>
            <div>
              <div className="badge" style={{color:"var(--ok)"}}>&#10003; PRD Generated</div>
              <h2 style={{fontSize:22,fontWeight:700,color:"var(--hd)",margin:"6px 0 0"}}>Your Product Requirements Document</h2>
            </div>
          </div>
          <div className="c" style={{marginBottom:18}}>
            <div style={{fontSize:14,lineHeight:1.8}} dangerouslySetInnerHTML={{__html:renderMd(prd)}}/>
          </div>
          <div className="rb" style={{flexWrap:"wrap"}}>
            <button className="bp" onClick={copy}>{copied?"✓ Copied!":"Copy to Clipboard"}</button>
            <button className="bs" onClick={()=>setPrd("")}>← Back to Edit</button>
            <button className="bs" onClick={reset}>Start Over</button>
          </div>
        </div>
      )}

      {/* LOADING */}
      {loading && !prd && (
        <div className="w fi" style={{textAlign:"center",paddingTop:120}}>
          <div style={{fontSize:38,marginBottom:16}}>⚡</div>
          <h2 style={{fontSize:19,fontWeight:600,color:"var(--hd)",margin:"0 0 8px"}}>Generating your PRD...</h2>
          <p className="sub">Structuring requirements, defining metrics, polishing</p>
        </div>
      )}

      {/* INTERVIEW */}
      {mode==="interview" && !loading && !prd && (
        <div className="w fi">
          <div className="rbb" style={{marginBottom:28}}>
            <button className="bs" style={{padding:"5px 12px",fontSize:12}} onClick={reset}>← Modes</button>
            <span style={{fontSize:13,color:"var(--tx2)"}}>{step+1} / {QUESTIONS.length}</span>
          </div>
          <div className="rb" style={{gap:5,marginBottom:28}}>
            {QUESTIONS.map((_,i)=>(<div key={i} className={`dot ${i===step?"don":i<step?"dd":"dof"}`}/>))}
          </div>
          <div className="c">
            <div style={{fontSize:17,fontWeight:600,color:"var(--hd)",marginBottom:14,lineHeight:1.4}}>{q.q}</div>
            {q.multi?(
              <textarea ref={iRef} className="ta" value={input} onChange={e=>setInput(e.target.value)} placeholder={q.placeholder} rows={5}
                onKeyDown={e=>{if(e.key==="Enter"&&(e.metaKey||e.ctrlKey))next()}}/>
            ):(
              <input ref={iRef} className="inp" value={input} onChange={e=>setInput(e.target.value)} placeholder={q.placeholder}
                onKeyDown={e=>{if(e.key==="Enter")next()}}/>
            )}
            <div className="rbb" style={{marginTop:16}}>
              <button className="bs" style={{visibility:step>0?"visible":"hidden"}} onClick={back}>← Back</button>
              <div className="rb">
                {!isLast&&<button className="bp" disabled={!input.trim()} onClick={next}>Next →</button>}
                {isLast&&<button className="bp bok" disabled={!input.trim()&&!ans[q.key]} onClick={genInterview}>⚡ Generate PRD</button>}
              </div>
            </div>
            {q.multi&&<div style={{fontSize:11,color:"var(--tx2)",marginTop:8,textAlign:"right"}}>⌘/Ctrl+Enter to continue</div>}
          </div>
          {step>0&&(
            <div className="pa">
              <div style={{fontSize:11,color:"var(--tx2)",marginBottom:8,textTransform:"uppercase",letterSpacing:1}}>Your answers</div>
              {QUESTIONS.slice(0,step).map((iq,i)=>(
                <div key={i} className="pi"><div className="pq">{iq.q}</div><div>{ans[iq.key]}</div></div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* NOTES */}
      {mode==="notes" && !loading && !prd && (
        <div className="w fi">
          <div className="rbb" style={{marginBottom:24}}>
            <button className="bs" style={{padding:"5px 12px",fontSize:12}} onClick={reset}>← Modes</button>
            <span className="badge">Notes → PRD</span>
          </div>
          <div className="c">
            <h2 style={{fontSize:18,fontWeight:600,color:"var(--hd)",margin:"0 0 4px"}}>Paste your rough notes</h2>
            <p className="sub" style={{margin:"0 0 16px"}}>Brain dump everything — meeting notes, bullet points, half-formed ideas. AI will structure it.</p>
            <textarea ref={iRef} className="ta" value={notes} onChange={e=>setNotes(e.target.value)} rows={13}
              placeholder={"e.g.,\n- We need a loyalty feature to stop churn\n- Gamified streaks like Duolingo?\n- Target: 20% more repeat orders\n- Push notifs for reorder reminders\n- Integrate with existing points system\n- Out of scope: international markets"}/>
            <div style={{display:"flex",justifyContent:"flex-end",marginTop:14}}>
              <button className="bp bok" disabled={!notes.trim()} onClick={genNotes}>⚡ Generate PRD</button>
            </div>
          </div>
        </div>
      )}

      {/* TEMPLATE */}
      {mode==="template" && !loading && !prd && (
        <div className="ww fi">
          <div className="rbb" style={{marginBottom:24}}>
            <button className="bs" style={{padding:"5px 12px",fontSize:12}} onClick={reset}>← Modes</button>
            <span className="badge">Template + AI</span>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            {SECTIONS.map(sec=>(
              <div key={sec.key} className="c">
                <div className="rbb" style={{marginBottom:10}}>
                  <h3 style={{fontSize:15,fontWeight:600,color:"var(--hd)",margin:0}}>{sec.title}</h3>
                  <button className="bs" style={{padding:"5px 12px",fontSize:12}} disabled={secLoad===sec.key} onClick={()=>aiSec(sec)}>
                    {secLoad===sec.key?<><span className="sp"/>Working...</>:`✨ ${sec.ai}`}
                  </button>
                </div>
                <textarea className="ta" value={tpl[sec.key]||""} onChange={e=>setTpl(d=>({...d,[sec.key]:e.target.value}))}
                  placeholder={sec.placeholder} rows={6}/>
              </div>
            ))}
          </div>
          <div style={{display:"flex",justifyContent:"flex-end",marginTop:20}}>
            <button className="bp bok" disabled={!Object.values(tpl).some(v=>v?.trim())} onClick={genTpl}>⚡ Combine into Full PRD</button>
          </div>
        </div>
      )}
    </div>
  );
}
